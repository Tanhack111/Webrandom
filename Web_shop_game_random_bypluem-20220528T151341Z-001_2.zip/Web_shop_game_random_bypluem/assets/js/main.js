console.log("เว็บนี้เขียนโดย FB : Pluem Patiphan");
console.log("ติดต่อจ้างเขียนเว็บ FB : Patiphan Srieamkul");